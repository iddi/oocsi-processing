package nl.tue.id.oocsi.client.data;

import java.util.Timer;
import java.util.TimerTask;

import nl.tue.id.oocsi.client.OOCSIClient;
import nl.tue.id.oocsi.client.protocol.OOCSIMessage;

/**
 * 
 * 
 * 
 * @author matsfunk
 */
public class OOCSIGenerator {

	// OOCSI client for outgoing communication
	private OOCSIClient client;

	// channel or client handle for outgoing communication
	private String outputChannelName;

	// key to assign the data for outgoing communication
	private String outputKey;

	// internal variable to hold the data that will be manipulated and generated (sent out)
	private OOCSIVariable<Number> variable;

	/**
	 * creates a generator component on an OOCSIVariable
	 * 
	 * @param client
	 * @param variable
	 * @param periodMS
	 */
	public OOCSIGenerator(OOCSIClient client, OOCSIVariable<Number> variable, long periodMS) {
		this(client, variable, null, null, periodMS);
	}

	/**
	 * creates a generator component on an OOCSIVariable
	 * 
	 * @param client
	 * @param variable
	 * @param outputChannelName
	 * @param outputKey
	 * @param periodMS
	 */
	public OOCSIGenerator(OOCSIClient client, OOCSIVariable<Number> variable, String outputChannelName,
			String outputKey, long periodMS) {
		this.client = client;
		this.outputChannelName = outputChannelName;
		this.outputKey = outputKey;

		// start time to update this flow
		new Timer(true).schedule(new TimerTask() {
			public void run() {
				update();
			}
		}, periodMS, periodMS);
	}

	/**
	 * periodically called to update the variable with its reference value
	 * 
	 */
	private void update() {

		// update variable
		variable.set(variable.last());

		// send out
		new OOCSIMessage(client, outputChannelName).data(outputKey, variable.get()).send();
	}

}
